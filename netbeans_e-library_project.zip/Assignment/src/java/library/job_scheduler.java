/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package library;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

/**
 *
 * @author THeHeCtor
 */
public class job_scheduler{



public void updater()
{
    ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
    Runnable runnable = new Runnable() {
        public void run()
        {
            Connection con = null;
  
            try{
            con = createConnection();
                if (con != null) {

                    PreparedStatement stmt = con.prepareStatement("SELECT user_id,isbn, copy_number,last_reminder_date,issue_date,due_date,returned_date FROM books_on_loan where returned_date is null");
                    ResultSet rs = stmt.executeQuery();
                    while(rs.next()) {
                        boolean a =false;
                        java.util.Date newDate1 =new java.util.Date(rs.getDate("due_date").getTime());
                        java.util.Date newDate = new java.util.Date(rs.getDate("due_date").getTime());
                        if((rs.getDate("last_reminder_date")!= null)){
                            newDate1 = new java.util.Date(rs.getDate("last_reminder_date").getTime());
                            a = true;
                        }
                        java.util.Date today = new java.util.Date();
                        Format formatter = new SimpleDateFormat("yyyy-MM-dd");
                        String s = formatter.format(today.getTime());
                        String s1 = formatter.format(newDate);
                        String s2 = null;
                        System.out.println(s +"  "+s1);
                        if(a){
                            s2 = formatter.format(newDate1);}
                        Example obj= new Example();
                        int t1= obj.numberOfDays(s1,s );
                        int t2=0;
                        if(a){
                            t2 = obj.numberOfDays(s2,s );}
                        System.out.println(t1);
                       
                        System.out.println(t2);
                        if(a){
                            if(((t1>31 && t2 > 15 ))&& rs.getDate("returned_date")==null){
                                System.out.println("adfadsfadsf");
                                PreparedStatement stmt1 = con.prepareStatement("update books_on_loan set last_reminder_date= ? where user_id like ? and isbn like ? and copy_number= ? and issue_date = ? and due_date = ? ");
                                stmt1.setDate(1,new java.sql.Date(today.getTime()) );
                                stmt1.setString(2,rs.getString("user_id"));
                                stmt1.setString(3,rs.getString("isbn"));
                                stmt1.setInt(4,rs.getInt("copy_number"));
                                stmt1.setDate(5,rs.getDate("issue_date"));
                                stmt1.setDate(6,rs.getDate("due_date"));
                                
                                stmt1.execute();
                                PreparedStatement stmt2 = con.prepareStatement("select email_id from users where user_id like ?");
                                stmt2.setString(1, rs.getString("user_id"));
                                ResultSet rs2=stmt2.executeQuery();
                                mail obj1 = new mail();
                                if(rs2.next())
                                    obj1.send_main(rs2.getString("email_id"));
                            }}
                            else if(t1>31 && rs.getDate("returned_date")==null)
                            {
                                System.out.println("adfadsfadsf11111");
                                PreparedStatement stmt1 = con.prepareStatement("update books_on_loan set last_reminder_date= ? where user_id like ? and isbn like ? and copy_number= ? and issue_date = ? and due_date = ? ");
                                stmt1.setDate(1,new java.sql.Date(today.getTime()) );
                                stmt1.setString(2,rs.getString("user_id"));
                                stmt1.setString(3,rs.getString("isbn"));
                                stmt1.setInt(4,rs.getInt("copy_number"));
                                stmt1.setDate(5,rs.getDate("issue_date"));
                                stmt1.setDate(6,rs.getDate("due_date"));
                                
                                stmt1.execute();
                                PreparedStatement stmt2 = con.prepareStatement("select email_id from users where user_id like ?");
                                stmt2.setString(1, rs.getString("user_id"));
                                ResultSet rs2=stmt2.executeQuery();
                                mail obj1 = new mail();
                                if(rs2.next())
                                    obj1.send_main(rs2.getString("email_id"));
                            }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (con != null) {
                    try {
                        con.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        
       
    };

    // Run it in 8 hours - you would have to calculate how long to wait from "now"
    service.schedule(runnable, 8, TimeUnit.SECONDS); // You can 
}
 public Connection createConnection() {
  System.out.println("Createung postgres DataBase Connection");
  Connection connection = null;

  try {
   
   // Provide database Driver according to your database
   Class.forName("org.postgresql.Driver");
   
   // Provide URL, database and credentials according to your database 
   connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/library", "postgres","mint");

  } catch (Exception e) {
   e.printStackTrace();
   System.out.println(e);
   return null;
  }
  if(connection != null){
   System.out.println("Connection created successfully....");
  }
  return connection;
 }

}
