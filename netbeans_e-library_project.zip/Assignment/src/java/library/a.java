/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package library;

/**
 *
 * @author THeHeCtor
 */
public class a {
    public static void main(String[] args)
    {
        
      Thread t1;
      t1 = new Thread(new Runnable(){@Override
      public void run(){
          job_scheduler R1 = new job_scheduler();
        R1.updater();
      }
      });
      
      Thread t2;
      t2 = new Thread(new Runnable(){@Override
      public void run(){
          job_scheduler2 R2 = new job_scheduler2();
        R2.updater1();
      }
      });
      t1.start();
      t2.start();
 
       //System.out.println(yearFrom + monFrom + ddFrom);
    }
    
}
